# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 11:29:12 2022

@author: tille
"""


import numpy as np
import pandas as pd

def interpolate_data(in_file, out_file):
    df_X = pd.read_csv(in_file)
    #df_TEST = pd.read_csv('test_features.csv')
      
    group_x = df_X.groupby('pid')
    
    df_output = group_x['Age'].first()
    
    new_col = pd.DataFrame()
    
    for col in df_X.columns[3:]:
        new_col = group_x[col].apply(lambda x: pd.Series(x.values)).unstack()
        new_col = new_col.interpolate(methode='linear',axis=1).fillna(method='backfill',axis = 1)
        new_col = new_col.fillna(df_X[col].median())
        new_col = new_col.add_prefix(col+'_')
        
        df_output = pd.concat([df_output, new_col], axis=1)
    
    df_output.to_csv(out_file, index=True, header=True)
    
#interpolate_data('test_features.csv','test.csv')
