# -*- coding: utf-8 -*-
"""
Created on Sun Apr 24 16:09:58 2022

@author: tille
"""
from xgboost import XGBRegressor

def predict(df_X,label,df_test):
    clf = XGBRegressor(alpha = 50) 
    clf.fit(df_X,label)
    return clf.predict(df_test)