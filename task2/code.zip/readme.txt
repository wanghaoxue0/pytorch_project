# to install xgboost
pip install xgboost

# you need to have test_feature, train_label and train_feature in the same directory