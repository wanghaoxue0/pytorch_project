# -*- coding: utf-8 -*-
"""
Created on Sun Apr 24 15:30:50 2022

@author: tille
"""


import data_cleaning 
import classify
import regress 
import pandas as pd
import numpy as np

trainig_raw = 'train_features.csv'
trainig_clean = 'features.csv'
trainig_label = 'train_labels.csv'
test_raw = 'test_features.csv'
test_clean = 'test.csv'

VITALS = ['LABEL_RRate', 'LABEL_ABPm', 'LABEL_SpO2', 'LABEL_Heartrate']
TESTS = ['LABEL_BaseExcess', 'LABEL_Fibrinogen', 'LABEL_AST', 'LABEL_Alkalinephos', 'LABEL_Bilirubin_total',
         'LABEL_Lactate', 'LABEL_TroponinI', 'LABEL_SaO2',
         'LABEL_Bilirubin_direct', 'LABEL_EtCO2','LABEL_Sepsis']

data_cleaning.interpolate_data(trainig_raw, trainig_clean)
data_cleaning.interpolate_data(test_raw, test_clean)

df_X = pd.read_csv(trainig_clean).set_index('pid').sort_index()
df_Y = pd.read_csv(trainig_label).set_index('pid').sort_index()
df_test = pd.read_csv(test_clean).set_index('pid')


prediction_clf = [ classify.predict(df_X, df_Y[label], df_test) for label in TESTS]
df_clf = pd.DataFrame(np.array(prediction_clf).T, columns=TESTS)

prediction_reg = [ regress.predict(df_X, df_Y[label], df_test) for label in VITALS]
df_reg = pd.DataFrame(np.array(prediction_reg).T, columns=VITALS)


test_pid = pd.DataFrame(df_test.index.values.T,columns=['pid'])
output = pd.concat([test_pid, df_clf,df_reg],axis=1).set_index('pid')
output.to_csv('prediction.csv', index=True, float_format='%.3f')